import React from 'react'
import DocumentBuilder from './components/DocumentBuilder/DocumentBuilder'

export default function App() {
  return <DocumentBuilder />
}